"""Employee service — registration, profile, stats with cache."""
import logging
from typing import Optional
from app.integrations.google_sheets import (
    get_sheets, SHEET_EMPLOYEES, SHEET_POINT_TRANSACTIONS,
    SHEET_SCANS_RAW, SHEET_SYSTEM_LOGS,
)
from app.utils.ids import generate_employee_id, generate_employee_code, generate_log_id
from app.utils.datetime_utils import now_str, start_of_day_utc, start_of_week_utc, start_of_month_utc
from app.utils.cache import employees_cache, invalidate_employee

logger = logging.getLogger(__name__)


def _norm_ts(ts):
    ts = (ts or "").strip()
    if len(ts) == 16:
        return ts + ":00"
    return ts


def register_employee(telegram_user_id, telegram_username, full_name, phone,
                       country_code, language_code):
    sheets = get_sheets()
    existing = get_employee_by_telegram_id(telegram_user_id)
    if existing:
        return existing

    seq = sheets.get_next_seq(SHEET_EMPLOYEES)
    employee_id = generate_employee_id(seq)
    country_employees = sheets.find_records(SHEET_EMPLOYEES, "country_code", country_code.upper())
    country_seq = len(country_employees) + 1
    emp_code = generate_employee_code(country_code, country_seq)

    from app.config import settings
    short_link = f"{settings.TRACKING_DOMAIN}/r/{emp_code}"

    row = [
        employee_id, emp_code, full_name, phone,
        str(telegram_user_id), telegram_username or "",
        country_code.upper(), language_code.lower(),
        "active", now_str(), now_str(), "", short_link, ""
    ]
    sheets.append_row(SHEET_EMPLOYEES, row)
    invalidate_employee(employee_id=employee_id, telegram_user_id=str(telegram_user_id),
                        employee_code=emp_code)

    _log(sheets, "employee_created", "employee", employee_id,
         f"Employee created: {emp_code} ({full_name})")
    logger.info("Employee registered: %s / %s", employee_id, emp_code)
    return get_employee_by_telegram_id(telegram_user_id)


def get_employee_by_telegram_id(telegram_user_id):
    key = f"tg:{telegram_user_id}"
    cached = employees_cache.get(key)
    if cached is not None:
        return cached
    sheets = get_sheets()
    result = sheets.find_record(SHEET_EMPLOYEES, "telegram_user_id", str(telegram_user_id))
    if result:
        employees_cache.set(key, result)
    return result


def get_employee_by_id(employee_id):
    key = f"id:{employee_id}"
    cached = employees_cache.get(key)
    if cached is not None:
        return cached
    sheets = get_sheets()
    result = sheets.find_record(SHEET_EMPLOYEES, "employee_id", employee_id)
    if result:
        employees_cache.set(key, result)
    return result


def get_employee_by_code(employee_code):
    key = f"code:{employee_code}"
    cached = employees_cache.get(key)
    if cached is not None:
        return cached
    sheets = get_sheets()
    result = sheets.find_record(SHEET_EMPLOYEES, "employee_code", employee_code)
    if result:
        employees_cache.set(key, result)
    return result


def update_employee_qr(employee_id, qr_id):
    sheets = get_sheets()
    row_idx = sheets.find_row_index(SHEET_EMPLOYEES, "employee_id", employee_id)
    if row_idx:
        sheets.update_row(SHEET_EMPLOYEES, row_idx, {"qr_id": qr_id, "last_active_at": now_str()})
    invalidate_employee(employee_id=employee_id)


def update_employee_status(employee_id, status, updated_by="admin"):
    sheets = get_sheets()
    row_idx = sheets.find_row_index(SHEET_EMPLOYEES, "employee_id", employee_id)
    if row_idx:
        sheets.update_row(SHEET_EMPLOYEES, row_idx, {"status": status})
    invalidate_employee(employee_id=employee_id)
    _log(sheets, "employee_status_changed", "employee", employee_id,
         f"Status changed to {status} by {updated_by}")


def update_employee_language(telegram_user_id, language_code):
    sheets = get_sheets()
    row_idx = sheets.find_row_index(SHEET_EMPLOYEES, "telegram_user_id", str(telegram_user_id))
    if row_idx:
        sheets.update_row(SHEET_EMPLOYEES, row_idx, {"language_code": language_code})
    invalidate_employee(telegram_user_id=str(telegram_user_id))


def get_employee_stats(employee_id):
    sheets = get_sheets()
    txs = sheets.find_records(SHEET_POINT_TRANSACTIONS, "employee_id", employee_id)
    scans = sheets.find_records(SHEET_SCANS_RAW, "employee_id", employee_id)

    total_points = sum(int(t.get("points_delta", 0) or 0) for t in txs)
    day_start = start_of_day_utc().strftime("%Y-%m-%d")
    week_start = start_of_week_utc().strftime("%Y-%m-%d")
    month_start = start_of_month_utc().strftime("%Y-%m-%d %H:%M:%S")

    today_pts = sum(int(t.get("points_delta", 0) or 0) for t in txs
                    if _norm_ts(t.get("created_at", "")) >= day_start)
    week_pts = sum(int(t.get("points_delta", 0) or 0) for t in txs
                   if _norm_ts(t.get("created_at", "")) >= week_start)
    month_pts = sum(int(t.get("points_delta", 0) or 0) for t in txs
                    if _norm_ts(t.get("created_at", "")) >= month_start)

    unique_devices = len({s.get("device_key") for s in scans
                          if s.get("point_decision") == "first_unique_device"})
    duplicate_scans = len([s for s in scans if s.get("point_decision") == "duplicate_device"])

    from app.services.events_service import get_all_events
    event_points = []
    event_map = {e.get("event_id"): e for e in get_all_events()}
    for event_id, event in event_map.items():
        start_ts = _norm_ts(event.get("started_at") or event.get("start_at") or "")
        if not start_ts:
            continue
        ev_points = sum(int(t.get("points_delta", 0) or 0) for t in txs
                        if t.get("event_id") == event_id and _norm_ts(t.get("created_at", "")) >= start_ts)
        if ev_points != 0:
            event_points.append({"event_id": event_id,
                                 "event_name": event.get("event_name") or event_id,
                                 "points": ev_points})
    event_points.sort(key=lambda x: (-x["points"], x["event_name"]))

    return {
        "total_points": total_points, "today_points": today_pts,
        "week_points": week_pts, "month_points": month_pts,
        "unique_devices": unique_devices, "duplicate_scans": duplicate_scans,
        "total_scans": len(scans), "event_points": event_points,
    }


def get_all_employees():
    sheets = get_sheets()
    return sheets.get_all_records(SHEET_EMPLOYEES)


def update_last_active(telegram_user_id):
    sheets = get_sheets()
    row_idx = sheets.find_row_index(SHEET_EMPLOYEES, "telegram_user_id", str(telegram_user_id))
    if row_idx:
        sheets.update_row(SHEET_EMPLOYEES, row_idx, {"last_active_at": now_str()})


def _log(sheets, action, entity_type, entity_id, message, level="INFO"):
    seq = sheets.get_next_seq(SHEET_SYSTEM_LOGS)
    sheets.append_row(SHEET_SYSTEM_LOGS, [
        generate_log_id(seq), now_str(), level, action, entity_type, entity_id, message
    ])
